package com.demo.h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjecWebH24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
