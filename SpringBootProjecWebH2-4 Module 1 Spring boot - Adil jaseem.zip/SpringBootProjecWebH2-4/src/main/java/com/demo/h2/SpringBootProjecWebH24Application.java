package com.demo.h2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjecWebH24Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjecWebH24Application.class, args);
	}

}
